<?php
// Incluir as configurações e a conexão com o banco de dados
include_once 'config.php';

// Se o download do PDF de todos os alunos for solicitado
if (isset($_GET['download_all_pdf']) && $_GET['download_all_pdf'] === 'true' && isset($_GET['numero_turma']) && isset($_GET['ano_turma'])) {
    // Incluir o FPDF
    require_once('fpdf/fpdf.php');

    // Obter os dados da turma
    $numero_turma = $_GET['numero_turma'];
    $ano_turma = $_GET['ano_turma'];

    // Consultar os discentes dessa turma
    $query_discentes = "
        SELECT d.numero_matricula, d.nome
        FROM discentes_turmas dt
        JOIN discentes d ON dt.numero_matricula = d.numero_matricula
        WHERE dt.turma_numero = ? AND dt.turma_ano = ?
    ";
    $stmt_discentes = $conn->prepare($query_discentes);
    $stmt_discentes->bind_param('ii', $numero_turma, $ano_turma);
    $stmt_discentes->execute();
    $result_discentes = $stmt_discentes->get_result();

    // Criar o PDF
    $pdf = new FPDF();
    $pdf->SetFont('Arial', '', 12);

    // Para cada discente, gerar uma página com o boletim
    while ($discente = $result_discentes->fetch_assoc()) {
        // Consultar as notas do discente
        $numero_matricula = $discente['numero_matricula'];
        $query_boletim_pdf = "
            SELECT n.nota_final, n.nota_exame, n.parcial_1, n.nota_semestre_1, n.parcial_2, n.nota_semestre_2, 
                   n.faltas, n.observacoes, d.nome AS disciplina_nome
            FROM notas n
            JOIN disciplinas d ON n.disciplina_id = d.id
            WHERE n.discente_id = ?
        ";
        $stmt_boletim_pdf = $conn->prepare($query_boletim_pdf);
        $stmt_boletim_pdf->bind_param('i', $numero_matricula);
        $stmt_boletim_pdf->execute();
        $result_boletim_pdf = $stmt_boletim_pdf->get_result();

        // Adicionar uma página para o aluno
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Boletim do Discente: ' . $discente['nome'], 0, 1, 'C');
        $pdf->Ln(10); // Adiciona um espaçamento

        // Definir largura das colunas para a tabela
        $col_widths = [60, 30, 30, 30, 30, 30, 30, 30, 40];
        $pdf->SetFont('Arial', 'B', 12);

        // Ajustar a largura das colunas
$col_widths = [60, 30, 30, 30, 30, 30, 30, 30, 40];

// Adicionando o cabeçalho da tabela
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(200, 220, 255); // Cor de fundo azul claro
$pdf->Cell($col_widths[0], 10, 'Disciplina', 1, 0, 'C', true);
$pdf->Cell($col_widths[1], 10, 'Parcial 1', 1, 0, 'C', true);
$pdf->Cell($col_widths[2], 10, 'Nota Sem. 1', 1, 0, 'C', true);
$pdf->Cell($col_widths[3], 10, 'Parcial 2', 1, 0, 'C', true);
$pdf->Cell($col_widths[4], 10, 'Nota Sem. 2', 1, 0, 'C', true);
$pdf->Cell($col_widths[5], 10, 'Nota Final', 1, 0, 'C', true);
$pdf->Cell($col_widths[6], 10, 'Nota Exame', 1, 0, 'C', true);
$pdf->Cell($col_widths[7], 10, 'Faltas', 1, 0, 'C', true);
$pdf->Cell($col_widths[8], 10, 'Observações', 1, 1, 'C', true);

// Preenchendo as linhas com os dados do boletim
$pdf->SetFont('Arial', '', 12);
while ($boletim = $result_boletim_pdf->fetch_assoc()) {
    $pdf->Cell($col_widths[0], 10, utf8_decode($boletim['disciplina_nome']), 1, 0, 'C');
    $pdf->Cell($col_widths[1], 10, utf8_decode($boletim['parcial_1']), 1, 0, 'C');
    $pdf->Cell($col_widths[2], 10, utf8_decode($boletim['nota_semestre_1']), 1, 0, 'C');
    $pdf->Cell($col_widths[3], 10, utf8_decode($boletim['parcial_2']), 1, 0, 'C');
    $pdf->Cell($col_widths[4], 10, utf8_decode($boletim['nota_semestre_2']), 1, 0, 'C');
    $pdf->Cell($col_widths[5], 10, ($boletim['nota_final'] !== null ? utf8_decode($boletim['nota_final']) : 'N/A'), 1, 0, 'C');
    $pdf->Cell($col_widths[6], 10, ($boletim['nota_exame'] !== null ? utf8_decode($boletim['nota_exame']) : 'N/A'), 1, 0, 'C');
    $pdf->Cell($col_widths[7], 10, utf8_decode($boletim['faltas']), 1, 0, 'C');
    $pdf->MultiCell($col_widths[8], 10, utf8_decode($boletim['observacoes']), 1, 'C');
}


        $stmt_boletim_pdf->close();
    }

    $stmt_discentes->close();

    // Finalizar e gerar o PDF para download
    $pdf->Output('D', 'boletins_turma_' . $numero_turma . '_' . $ano_turma . '.pdf');  // 'D' significa download
    exit;  // Evitar que o restante do HTML seja exibido após o PDF ser gerado
}

// Exibição de turmas (não alterada)
$query_turmas = "
    SELECT t.numero, t.ano, c.nome AS curso_nome
    FROM turmas t
    JOIN cursos c ON t.curso_id = c.id
    ORDER BY t.ano DESC, t.numero ASC
";
$result_turmas = $conn->query($query_turmas);

if ($result_turmas->num_rows > 0) {
    echo "<h1>Selecione uma Turma</h1>";
    echo "<ul>";

    // Exibir lista de turmas
    while ($turma = $result_turmas->fetch_assoc()) {
        echo "<li><a href='gerar_boletim.php?numero_turma=" . $turma['numero'] . "&ano_turma=" . $turma['ano'] . "'>Turma " . $turma['numero'] . " - " . $turma['curso_nome'] . " (" . $turma['ano'] . ")</a> 
                <a href='gerar_boletim.php?download_all_pdf=true&numero_turma=" . $turma['numero'] . "&ano_turma=" . $turma['ano'] . "'>Gerar PDF Todos</a></li>";
    }

    echo "</ul>";
} else {
    echo "<p>Nenhuma turma cadastrada.</p>";
}

// Exibição de turmas e discentes (não alterado)
$query_turmas = "
    SELECT t.numero, t.ano, c.nome AS curso_nome
    FROM turmas t
    JOIN cursos c ON t.curso_id = c.id
    ORDER BY t.ano DESC, t.numero ASC
";
$result_turmas = $conn->query($query_turmas);

if ($result_turmas->num_rows > 0) {
    echo "<h1>Selecione uma Turma</h1>";
    echo "<ul>";

    // Exibir lista de turmas
    while ($turma = $result_turmas->fetch_assoc()) {
        echo "<li><a href='gerar_boletim.php?numero_turma=" . $turma['numero'] . "&ano_turma=" . $turma['ano'] . "'>Turma " . $turma['numero'] . " - " . $turma['curso_nome'] . " (" . $turma['ano'] . ")</a></li>";
    }

    echo "</ul>";
} else {
    echo "<p>Nenhuma turma cadastrada.</p>";
}

if (isset($_GET['numero_turma']) && isset($_GET['ano_turma'])) {
    // Consultar os discentes dessa turma
    $numero_turma = $_GET['numero_turma'];
    $ano_turma = $_GET['ano_turma'];

    $query_discentes = "
        SELECT d.numero_matricula, d.nome, d.email, d.cidade
        FROM discentes_turmas dt
        JOIN discentes d ON dt.numero_matricula = d.numero_matricula
        WHERE dt.turma_numero = ? AND dt.turma_ano = ?
    ";
    $stmt_discentes = $conn->prepare($query_discentes);
    $stmt_discentes->bind_param('ii', $numero_turma, $ano_turma);
    $stmt_discentes->execute();
    $result_discentes = $stmt_discentes->get_result();

    if ($result_discentes->num_rows > 0) {
        echo "<h2>Discentes da Turma " . $numero_turma . " - Ano " . $ano_turma . "</h2>";
        echo "<table border='1'>";
        echo "<thead><tr><th>Nome</th><th>Email</th><th>Cidade</th><th>Ação</th></tr></thead>";
        echo "<tbody>";

        while ($discente = $result_discentes->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($discente['nome']) . "</td>";
            echo "<td>" . htmlspecialchars($discente['email']) . "</td>";
            echo "<td>" . htmlspecialchars($discente['cidade']) . "</td>";
            echo "<td><a href='gerar_boletim.php?numero_matricula=" . $discente['numero_matricula'] . "'>Ver Boletim</a></td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>Não há discentes cadastrados para essa turma.</p>";
    }

    $stmt_discentes->close();
}

// Se um aluno foi selecionado para ver o boletim
if (isset($_GET['numero_matricula'])) {
    $numero_matricula = $_GET['numero_matricula'];

    $query_boletim = "
        SELECT n.nota_final, n.nota_exame, n.parcial_1, n.nota_semestre_1, n.parcial_2, n.nota_semestre_2, 
               n.faltas, n.observacoes, d.nome AS disciplina_nome
        FROM notas n
        JOIN disciplinas d ON n.disciplina_id = d.id
        WHERE n.discente_id = ?
    ";
    $stmt_boletim = $conn->prepare($query_boletim);
    $stmt_boletim->bind_param('i', $numero_matricula);
    $stmt_boletim->execute();
    $result_boletim = $stmt_boletim->get_result();

    if ($result_boletim->num_rows > 0) {
        echo "<h2>Boletim do Discente</h2>";
        while ($boletim = $result_boletim->fetch_assoc()) {
            echo "<p><strong>Disciplina:</strong> " . $boletim['disciplina_nome'] . "</p>";
            echo "<p><strong>Parcial 1:</strong> " . $boletim['parcial_1'] . "</p>";
            echo "<p><strong>Nota Semestre 1:</strong> " . $boletim['nota_semestre_1'] . "</p>";
            echo "<p><strong>Parcial 2:</strong> " . $boletim['parcial_2'] . "</p>";
            echo "<p><strong>Nota Semestre 2:</strong> " . $boletim['nota_semestre_2'] . "</p>";
            echo "<p><strong>Nota Final:</strong> " . ($boletim['nota_final'] !== null ? $boletim['nota_final'] : 'N/A') . "</p>";
            echo "<p><strong>Nota Exame:</strong> " . ($boletim['nota_exame'] !== null ? $boletim['nota_exame'] : 'N/A') . "</p>";
            echo "<p><strong>Faltas:</strong> " . $boletim['faltas'] . "</p>";
            echo "<p><strong>Observações:</strong> " . $boletim['observacoes'] . "</p>";
        }
        echo "<br><a href='gerar_boletim.php?download_pdf=true&numero_matricula=" . $numero_matricula . "'>Gerar PDF</a>";
    } else {
        echo "<p>Boletim não encontrado.</p>";
    }

    $stmt_boletim->close();
}

$conn->close();
?>
