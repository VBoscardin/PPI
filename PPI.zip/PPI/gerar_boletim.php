<?php


session_start();


// Verificar se o usuário está autenticado e é um administrador
if (!isset($_SESSION['email']) || $_SESSION['user_type'] !== 'administrador') {
    header("Location: f_login.php");
    exit();
}
// Incluir as configurações e a conexão com o banco de dados
include_once 'config.php';


// Obter o nome e a foto do perfil do administrador logado
$stmt = $conn->prepare("SELECT username, foto_perfil FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$stmt->bind_result($nome, $foto_perfil);
$stmt->fetch();
$stmt->close();


// Incluir o FPDF
require_once('fpdf/fpdf.php');


// Função para calcular largura das colunas dinamicamente
function calculateColumnWidths($pdf, $headers, $selected_columns) {
    $pageWidth = $pdf->GetPageWidth() - 20; // Largura da página menos margens
    $numColumns = count($selected_columns) + 1; // Considera a coluna "Disciplina"
   
    // Definir largura mínima e máxima
    $minWidth = 2;
    $maxWidth = 60;
   
    // Distribuir largura proporcionalmente
    $colWidth = max($minWidth, min($maxWidth, $pageWidth / $numColumns));
   
    $columnWidths = [];
    foreach ($headers as $column => $width) {
        if ($column === 'Disciplina' || in_array($column, $selected_columns) || $column === 'Faltas') {
            $columnWidths[$column] = ($column === 'Disciplina') ? $colWidth + 40 : $colWidth;  // Aumenta a largura da coluna Disciplina
        }
    }
    return $columnWidths;
}




// Função para criar o cabeçalho da tabela com largura dinâmica
function addTableHeader($pdf, $headers, $selected_columns) {
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetFillColor(200, 200, 200); // Cinza para cabeçalho
   
    $columnWidths = calculateColumnWidths($pdf, $headers, $selected_columns);
   
    foreach ($columnWidths as $column => $width) {
        $pdf->Cell($width, 10, utf8_decode($column), 1, 0, 'C', true);
    }
    $pdf->Ln();
}


function addTableRow($pdf, $headers, $data, $selected_columns) {
    $pdf->SetFont('Arial', '', 12);
    $columnWidths = calculateColumnWidths($pdf, $headers, $selected_columns);
   
    $rowHeight = 6; // Altura mínima da linha
    $startX = $pdf->GetX();
    $startY = $pdf->GetY();
   
    // --- Passo 1: Calcular a altura da célula de "Disciplina" ---
    $disciplineWidth = $columnWidths['Disciplina'];
    $pdf->SetXY($startX, $startY);
    $pdf->MultiCell($disciplineWidth, $rowHeight, utf8_decode($data['Disciplina']), 1, 'C');
   
    // Obter a nova altura da célula "Disciplina" (ponto Y final - ponto Y inicial)
    $newY = $pdf->GetY();
    $cellHeight = $newY - $startY; // Essa será a altura para todas as outras células da linha
   
    // --- Passo 2: Desenhar as outras células ao lado da "Disciplina" ---
    $startX += $disciplineWidth; // Mover para a próxima coluna
   
    foreach ($columnWidths as $column => $width) {
        if ($column === 'Disciplina') {
            continue; // Já processamos essa coluna
        }


        // Garantir que só exibimos colunas que foram selecionadas
        if (in_array($column, $selected_columns)) {
            $pdf->SetXY($startX, $startY); // Manter alinhado na mesma altura da linha
            $pdf->Cell($width, $cellHeight, utf8_decode($data[$column]), 1, 0, 'C');
            $startX += $width; // Avançar para a próxima coluna
        }
    }


    // --- Passo 3: Pular para a próxima linha com altura ajustada ---
    $pdf->Ln($cellHeight);
}














// Se o download do PDF de todos os alunos for solicitado
if (isset($_GET['download_all_pdf']) && $_GET['download_all_pdf'] === 'true' && isset($_GET['numero_turma']) && isset($_GET['ano_turma'])) {
    // Obter os dados da turma
    $numero_turma = $_GET['numero_turma'];
    $ano_turma = $_GET['ano_turma'];


    // Verificar quais colunas foram selecionadas
    $selected_columns = isset($_GET['columns']) ? $_GET['columns'] : [];
    if (isset($_GET['include_final']) && $_GET['include_final'] === 'true') {
        $selected_columns = array_merge($selected_columns, ['Nota Final', 'Nota Exame', 'Faltas', 'Observações']);
    } else {
        // Garantir que a coluna Faltas sempre seja incluída, caso contrário.
        if (!in_array('Faltas', $selected_columns)) {
            $selected_columns[] = 'Faltas';
        }
    }


   


    // Criar o PDF
    $pdf = new FPDF();
    $pdf->SetAutoPageBreak(true, 30);  // Aumenta a margem inferior para 30mm


    $pdf->SetFont('Arial', '', 12); // Usar uma fonte compatível com UTF-8
    // Consultar os discentes dessa turma
    $query_discentes = "
    SELECT d.numero_matricula, d.nome, d.email, d.cidade
    FROM discentes_turmas dt
    JOIN discentes d ON dt.numero_matricula = d.numero_matricula
    WHERE dt.turma_numero = ? AND dt.turma_ano = ?
    ORDER BY d.nome ASC
    ";


    $stmt_discentes = $conn->prepare($query_discentes);
    $stmt_discentes->bind_param('ii', $numero_turma, $ano_turma);
    $stmt_discentes->execute();
    $result_discentes = $stmt_discentes->get_result();
   
    // Para cada discente, gerar uma página com o boletim
    while ($discente = $result_discentes->fetch_assoc()) {
        // Consultar as notas do discente
        $numero_matricula = $discente['numero_matricula'];
        // Consultar as disciplinas cursadas pelo aluno
$query_boletim_pdf = "
SELECT n.parcial_1, n.nota_semestre_1, n.parcial_2, n.nota_semestre_2,
       n.nota_final, n.nota_exame, n.faltas, n.observacoes, d.nome AS disciplina_nome
FROM notas n
JOIN disciplinas d ON n.disciplina_id = d.id
JOIN turmas_disciplinas td ON td.disciplina_id = d.id
WHERE n.discente_id = ? AND td.turma_numero = ?
ORDER BY d.nome ASC;
";


$stmt_boletim_pdf = $conn->prepare($query_boletim_pdf);
$stmt_boletim_pdf->bind_param('ii', $numero_matricula, $numero_turma);
$stmt_boletim_pdf->execute();
$result_boletim_pdf = $stmt_boletim_pdf->get_result();




        // Adicionar uma página para o aluno
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Boletim do Discente: ' . utf8_decode($discente['nome']), 0, 1, 'C');
        $pdf->Ln(5);


        // Adicionar cabeçalho da tabela
       
        $headers = [
            'Disciplina' => 40,
            'Parcial 1' => 20,
            'Sem. 1' => 25,  
            'Parcial 2' => 20,
            'Sem. 2' => 25,  
            'Nota Final' => 25,
            'Faltas' => 25,
        ];
       
       
        addTableHeader($pdf, $headers, $selected_columns);


        // Preencher as linhas com os dados
        $total_faltas = 0;
        $observacoes_completas = "";


        while ($boletim = $result_boletim_pdf->fetch_assoc()) {
            $observacoes_completas .= utf8_decode($boletim['observacoes']);


            $data = [];
            $data['Disciplina'] = $boletim['disciplina_nome'] ?? 'N/A';
            $data['Parcial 1'] = $boletim['parcial_1'] ?? 0;
            $data['Sem. 1'] = $boletim['nota_semestre_1'] ?? 0;
            $data['Parcial 2'] = $boletim['parcial_2'] ?? 0;
            $data['Sem. 2'] = $boletim['nota_semestre_2'] ?? 0;
            $data['Nota Final'] = $boletim['nota_final'] ?? 0;
            $data['Faltas'] =  $boletim['faltas'] ? $boletim['faltas'] : 0;
            addTableRow($pdf, $headers, $data, $selected_columns);


       
            // Acumular faltas
            $total_faltas += (int)$boletim['faltas'];
       
            // Concatenar observações
            $observacoes_completas .= $boletim['observacoes'] ?? '';
        }
       


        // Adicionar faltas totais e observações no final
        $pdf->Ln(5);  // Espaço antes de exibir faltas e observações
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 10, 'Faltas Totais: ' . $total_faltas, 0, 1, 'L');
        $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes_completas));


        $stmt_boletim_pdf->close();
    }


    $stmt_discentes->close();


    // Finalizar e gerar o PDF para download
    $pdf->Output('D', 'boletins_turma_' . $numero_turma . '_' . $ano_turma . '.pdf');
    exit;
}










// Consultar as turmas
$query_turmas = "
    SELECT t.numero, t.ano, c.nome AS curso_nome
    FROM turmas t
    JOIN cursos c ON t.curso_id = c.id
    ORDER BY t.ano DESC, t.numero ASC
";
$result_turmas = $conn->query($query_turmas);


// Consultar os discentes para exibir no HTML
$discentes = [];
if (isset($_GET['numero_turma']) && isset($_GET['ano_turma'])) {
    $numero_turma = $_GET['numero_turma'];
    $ano_turma = $_GET['ano_turma'];


    // Consultar os discentes dessa turma
    $query_discentes = "
        SELECT d.numero_matricula, d.nome, d.email, d.cidade
        FROM discentes_turmas dt
        JOIN discentes d ON dt.numero_matricula = d.numero_matricula
        WHERE dt.turma_numero = ? AND dt.turma_ano = ?
        ORDER BY d.nome ASC
    ";
    $stmt_discentes = $conn->prepare($query_discentes);
    $stmt_discentes->bind_param('ii', $numero_turma, $ano_turma);
    $stmt_discentes->execute();
    $result_discentes = $stmt_discentes->get_result();


    while ($discente = $result_discentes->fetch_assoc()) {
        $discentes[] = $discente;
    }


    $stmt_discentes->close();
}
// Gerar boletim individual para um aluno
if (isset($_GET['download_pdf']) && $_GET['download_pdf'] === 'true' && isset($_GET['numero_matricula'])) {
    $numero_matricula = $_GET['numero_matricula'];
   
    // Consultar os dados do discente
    $query_discente = "SELECT nome FROM discentes WHERE numero_matricula = ?";
    $stmt_discente = $conn->prepare($query_discente);
    $stmt_discente->bind_param('i', $numero_matricula);
    $stmt_discente->execute();
    $result_discente = $stmt_discente->get_result();
    $discente = $result_discente->fetch_assoc();  // Garantir que a variável 'discente' seja inicializada
    $stmt_discente->close();
   
    // Obter as colunas selecionadas
    $selected_columns = isset($_GET['columns']) ? $_GET['columns'] : [];
    if (isset($_GET['include_final']) && $_GET['include_final'] === 'true') {
        $selected_columns = array_merge($selected_columns, ['Nota Final', 'Nota Exame', 'Faltas', 'Observações']);
    }


    // Criar o PDF para o boletim individual
    $pdf = new FPDF();
    $pdf->SetAutoPageBreak(true, 30);  // Aumenta a margem inferior para 30mm


    $pdf->SetFont('Arial', '', 12);
   
    // Consultar as notas do aluno
    $query_boletim_pdf = "
    SELECT n.parcial_1, n.nota_semestre_1, n.parcial_2, n.nota_semestre_2,
           n.nota_final, n.nota_exame, n.faltas, n.observacoes, d.nome AS disciplina_nome
    FROM notas n
    JOIN disciplinas d ON n.disciplina_id = d.id
    JOIN turmas_disciplinas td ON td.disciplina_id = d.id
    WHERE n.discente_id = ?
    ORDER BY d.nome ASC;
    ";


    $stmt_boletim_pdf = $conn->prepare($query_boletim_pdf);
    $stmt_boletim_pdf->bind_param('i', $numero_matricula);
    $stmt_boletim_pdf->execute();
    $result_boletim_pdf = $stmt_boletim_pdf->get_result();


    // Adicionar uma página para o aluno
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Boletim do Discente: ' . utf8_decode($discente['nome']), 0, 1, 'C');
    $pdf->Ln(5);


    // Adicionar cabeçalho da tabela
    $headers = [
        'Disciplina' => 40,
        'Parcial 1' => 20,
        'Sem. 1' => 25,
        'Parcial 2' => 20,
        'Sem. 2' => 25,
        'Nota Final' => 25,
        'Faltas' => 25,
    ];


    addTableHeader($pdf, $headers, $selected_columns);


    // Preencher as linhas com os dados
    while ($boletim = $result_boletim_pdf->fetch_assoc()) {
        $data = [];
        $data['Disciplina'] = $boletim['disciplina_nome'] ?? 'N/A';
        $data['Parcial 1'] = $boletim['parcial_1'] ?? 0;
        $data['Sem. 1'] = $boletim['nota_semestre_1'] ?? 0;
        $data['Parcial 2'] = $boletim['parcial_2'] ?? 0;
        $data['Sem. 2'] = $boletim['nota_semestre_2'] ?? 0;
        $data['Nota Final'] = $boletim['nota_final'] ?? 0;
        $data['Faltas'] =  $boletim['faltas'] ? $boletim['faltas'] : 0;
        addTableRow($pdf, $headers, $data, $selected_columns);
    }


    // Finalizar e gerar o PDF para download
    $pdf->Output('D', 'boletim_' . $numero_matricula . '.pdf');
    exit;
}


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerar Boletim</title>
    <!-- Link do Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Forum:wght@700&display=swap" rel="stylesheet">
    <link href="style.css" rel="stylesheet" type="text/css"></head>
<body>
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-3 sidebar">
                <div class="separator mb-3"></div>
                <div class="signe-text">SIGNE</div>
                <div class="separator mt-3 mb-3"></div>
                <button onclick="location.href='f_pagina_adm.php'">
                    <i class="fas fa-home"></i> Início
                </button>
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#expandable-menu" aria-expanded="false" aria-controls="expandable-menu">
                    <i id="toggle-icon" class="fas fa-plus"></i> Cadastrar
                </button>
                <div id="expandable-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='cadastrar_adm.php'">
                            <i class="fas fa-plus"></i> Cadastrar Administrador
                        </button>
                        <button onclick="location.href='cadastrar_curso.php'">
                            <i class="fas fa-plus"></i> Cadastrar Curso
                        </button>
                        <button onclick="location.href='cadastrar_disciplina.php'">
                            <i class="fas fa-plus"></i> Cadastrar Disciplina
                        </button>
                        <button onclick="location.href='cadastrar_docente.php'">
                            <i class="fas fa-plus"></i> Cadastrar Docente
                        </button>
                        <button onclick="location.href='cadastrar_setor.php'">
                            <i class="fas fa-plus"></i> Cadastrar Setor
                        </button>
                        <button onclick="location.href='cadastrar_turma.php'">
                            <i class="fas fa-plus"></i> Cadastrar Turma
                        </button>
                    </div>
                </div>
                <button onclick="location.href='gerar_boletim.php'">
                    <i class="fas fa-file-alt"></i> Gerar Boletim
                </button>
                <button onclick="location.href='gerar_slide.php'">
                    <i class="fas fa-sliders-h"></i> Gerar Slide Pré Conselho
                </button>
               
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#list-menu" aria-expanded="false" aria-controls="list-menu">
                    <i id="toggle-icon" class="fas fa-list"></i> Listar
                </button>


                <div id="list-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='listar_administradores.php'">
                            <i class="fas fa-list"></i> Administradores
                        </button>
                        <button onclick="location.href='listar_cursos.php'">
                            <i class="fas fa-list"></i> Cursos
                        </button>
                        <button onclick="location.href='listar_discentes.php'">
                            <i class="fas fa-list"></i> Discentes
                        </button>
                        <button onclick="location.href='listar_disciplinas.php'">
                            <i class="fas fa-list"></i> Disciplinas
                        </button>
                        <button onclick="location.href='listar_docentes.php'">
                            <i class="fas fa-list"></i> Docentes
                        </button>
                        <button onclick="location.href='listar_setores.php'">
                            <i class="fas fa-list"></i> Setores
                        </button>
                        <button onclick="location.href='listar_turmas.php'">
                            <i class="fas fa-list"></i> Turmas
                        </button>
                    </div>
                </div>
                <button class="btn btn-danger" onclick="location.href='sair.php'">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>
            <div class="col-md-9 main-content">
            <div class="container">
                    <div class="header-container">
                        <img src="imgs/iffar.png" alt="Logo do IFFAR" class="logo">
                        <div class="title ms-3">Listar e Editar Disciplinas</div>
                        <div class="ms-auto d-flex align-items-center">
                            <div class="profile-info d-flex align-items-center">
                                <div class="profile-details me-2">
                                    <span><?php echo htmlspecialchars($nome); ?></span>
                                </div>
                                <?php if (!empty($foto_perfil) && file_exists('uploads/' . basename($foto_perfil))): ?>
                                    <img src="uploads/<?php echo htmlspecialchars(basename($foto_perfil)); ?>" alt="Foto do Administrador" width="50">
                                <?php else: ?>
                                    <img src="imgs/admin-photo.png" alt="Foto do Administrador" width="50">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container mt-4">
                <div class="card shadow">
                       
                        <div class="card-body">
        <!-- Exibição de Turmas -->
        <?php if ($result_turmas->num_rows > 0): ?>
            <h3 class="mb-4">Selecione uma Turma</h3>
            <ul class="list-group mb-4">
                <?php while ($turma = $result_turmas->fetch_assoc()): ?>
                    <li class="list-group-item">
                        <h4>Turma <?php echo $turma['numero']; ?> - <?php echo $turma['curso_nome']; ?> (<?php echo $turma['ano']; ?>)</h4>
                        <div class="mt-2">
                            <form method='GET' action='' class="d-inline-block">
                                <input type='hidden' name='download_all_pdf' value='true'>
                                <input type='hidden' name='numero_turma' value='<?php echo $turma['numero']; ?>'>
                                <input type='hidden' name='ano_turma' value='<?php echo $turma['ano']; ?>'>
                               
                                <!-- Colunas individuais -->
                                <?php
                                $columns = ['Parcial 1', 'Sem. 1', 'Parcial 2', 'Sem. 2'];
                                foreach ($columns as $column):
                                ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="columns[]" value="<?php echo $column; ?>">
                                        <label class="form-check-label"><?php echo $column; ?></label>
                                    </div>
                                <?php endforeach; ?>


                                <!-- Checkbox único para agrupar as colunas de Nota Final, Nota Exame, Faltas, Observações -->
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="include_final" value="true">
                                    <label class="form-check-label">Nota Final, Nota Exame, e Observações</label>
                                </div>


                                <button type="submit" class="btn btn-primary mt-3">Gerar Boletim</button>
                            </form>


                            <!-- Botão para ver os discentes dessa turma -->
                            <form method="GET" action="" class="d-inline-block ml-3">
                                <input type="hidden" name="numero_turma" value="<?php echo $turma['numero']; ?>">
                                <input type="hidden" name="ano_turma" value="<?php echo $turma['ano']; ?>">
                                <button type="submit" class="btn btn-secondary mt-3">Ver Discentes</button>
                            </form>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>Nenhuma turma cadastrada.</p>
        <?php endif; ?>


        <!-- Exibição de Discentes -->
<?php if (count($discentes) > 0): ?>
    <h2 class="mb-4">Discentes da Turma <?php echo $numero_turma . ' - Ano ' . $ano_turma; ?></h2>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Cidade</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($discentes as $discente): ?>
                <tr>
                    <td><?php echo $discente['nome']; ?></td>
                    <td><?php echo $discente['email']; ?></td>
                    <td><?php echo $discente['cidade']; ?></td>
                    <td>
                        <form method="GET" action="gerar_boletim.php">
                            <input type="hidden" name="download_pdf" value="true">
                            <input type="hidden" name="numero_matricula" value="<?php echo $discente['numero_matricula']; ?>">


                            <!-- Colunas individuais para o boletim do aluno -->
                            <?php
                            $columns = ['Parcial 1', 'Sem. 1', 'Parcial 2', 'Sem. 2'];
                            foreach ($columns as $column):
                            ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="columns[]" value="<?php echo $column; ?>">
                                    <label class="form-check-label"><?php echo $column; ?></label>
                                </div>
                            <?php endforeach; ?>


                            <!-- Checkbox único para agrupar as colunas de Nota Final, Nota Exame, Faltas, Observações -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="include_final" value="true">
                                <label class="form-check-label">Nota Final, Nota Exame, Faltas e Observações</label>
                            </div>


                            <button type="submit" class="btn btn-primary mt-3">Gerar PDF</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>


    </div>


    <!-- Adicionando o script do Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
