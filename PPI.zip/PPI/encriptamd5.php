<?php


$senha = "";

$senha_encriptada = md5($senha);


echo $senha_encriptada;


?>
