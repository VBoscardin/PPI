<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['email']) || !isset($_SESSION['user_type'])) {
    // Redirecionar para a página de login se o usuário não estiver autenticado
    header("Location: f_login.php");
    exit();
}

// Verificar se o usuário é um setor
if ($_SESSION['user_type'] !== 'setor') {
    // Redirecionar para uma página de acesso negado ou qualquer outra página
    header("Location: f_login.php");
    exit();
}

// Incluir o arquivo de conexão com o banco de dados
include('config.php'); // Substitua com o arquivo de conexão que você usa

// Consultar o nome do setor e a foto de perfil
$stmt = $conn->prepare("SELECT username, foto_perfil FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$stmt->bind_result($nome, $foto_perfil);
$stmt->fetch();
$stmt->close();

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['turma_numero'])) {
        $turma_numero = $_POST['turma_numero'];
    }

    if (isset($_POST['alunos'])) {
        // Itera sobre os alunos dessa turma e atualiza suas notas
        foreach ($_POST['alunos'] as $aluno_id => $notas) {
            $ais = $notas['ais'];
            $mostra_ciencias = $notas['mostra_ciencias'];
            $ppi = $notas['ppi'];
            $nota_exame = $notas['nota_exame'];

            // Atualizar as notas do aluno para essa turma
            $sql = "UPDATE notas
                    SET ais = ?, mostra_ciencias = ?, ppi = ?, nota_exame = ?
                    WHERE discente_id = ? AND turma_numero = ?";

            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("ddddii", $ais, $mostra_ciencias, $ppi, $nota_exame, $aluno_id, $turma_numero);
                if (!$stmt->execute()) {
                    $message = "Erro ao atualizar as notas para o aluno $aluno_id!";
                    break;
                }
            } else {
                $message = "Erro ao preparar a consulta!";
                break;
            }
        }

        $message = "Notas atualizadas com sucesso para todos os alunos da turma!";
    }
}

// Recuperar turmas para exibir no formulário
$sql_turmas = "SELECT numero, ano FROM turmas";
$result_turmas = $conn->query($sql_turmas);

// Se uma turma foi selecionada, buscar os alunos dessa turma e as notas
if (isset($turma_numero)) {
    $sql_alunos = "SELECT d.numero_matricula, d.nome
    FROM discentes d
    JOIN discentes_turmas dt ON d.numero_matricula = dt.numero_matricula
    WHERE dt.turma_numero = ?
    ORDER BY d.nome;";  

    $stmt = $conn->prepare($sql_alunos);
    $stmt->bind_param("i", $turma_numero);
    $stmt->execute();
    $result_alunos = $stmt->get_result();

    // Buscar as notas cadastradas para a turma
    $sql_notas = "SELECT discente_id, ais, mostra_ciencias, ppi, nota_exame 
                  FROM notas 
                  WHERE turma_numero = ?";
    $stmt_notas = $conn->prepare($sql_notas);
    $stmt_notas->bind_param("i", $turma_numero);
    $stmt_notas->execute();
    $result_notas = $stmt_notas->get_result();

    // Criar um array de notas já cadastradas
    $notas_cadastradas = [];
    while ($nota = $result_notas->fetch_assoc()) {
        $notas_cadastradas[$nota['discente_id']] = $nota;
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Notas Globais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet" type="text/css">
    <style>
        h3 {
            font-family: "Forum", "serif";
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Barra lateral -->
            <div class="col-md-3 sidebar">
                <div class="separator mb-3"></div>
                <div class="signe-text">SIGNE</div>
                <div class="separator mt-3 mb-3"></div>
                <button onclick="location.href='f_pagina_setor.php'">
                    <i class="fas fa-home"></i> Início
                </button>
                <button onclick="location.href='cadastrar_notas_globais.php'">
                    <i class="fas fa-th-list"></i> Cadastrar Notas Globais
                </button>
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#expandable-menu" aria-expanded="false" aria-controls="expandable-menu">
                    <i id="toggle-icon" class="fas fa-users"></i> Discentes
                </button>

                <!-- Menu expansível com Bootstrap -->
                <div id="expandable-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='cadastrar_discentes.php'">
                            <i class="fas fa-user-plus"></i> Cadastrar Discente
                        </button>
                    </div>
                    <div class="expandable-menu">
                        <button onclick="location.href='editar_discente.php'">
                            <i class="fas fa-user-edit"></i> Editar Discente
                        </button>
                    </div>
                </div>

                <button onclick="location.href='meu_perfil.php'">
                    <i class="fas fa-user"></i> Meu Perfil
                </button>
                <button class="btn btn-danger" onclick="location.href='sair.php'">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>

            <!-- Conteúdo principal -->
            <div class="col-md-9 main-content">
                <div class="container">
                    <div class="header-container">
                        <img src="imgs/iffar.png" alt="Logo do IFFAR" class="logo">
                        <div class="title ms-3">Página do Setor</div>
                        <div class="ms-auto d-flex align-items-center">
                            <div class="profile-info d-flex align-items-center">
                                <div class="profile-details me-2">
                                    <span><?php echo htmlspecialchars($nome); ?></span>
                                </div>
                                <?php if (!empty($foto_perfil) && file_exists('uploads/' . basename($foto_perfil))): ?>
                                    <img src="uploads/<?php echo htmlspecialchars(basename($foto_perfil)); ?>" alt="Foto do Setor">
                                <?php else: ?>
                                    <img src="imgs/setor-photo.png" alt="Foto do Setor">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid mt-4">
                    <div class="card shadow">
                        <div class="card-body">

    <form method="POST" action="cadastrar_notas_globais.php">
        <h3>Escolha uma turma:</h3>
        <br>
        <div class="d-flex flex-wrap gap-2">
            <?php while ($turma = $result_turmas->fetch_assoc()) { ?>
                <button class="btn btn-success mb-2" type="submit" name="turma_numero" value="<?php echo $turma['numero']; ?>">
                    <?php echo "Turma " . $turma['numero'] . " - " . $turma['ano']; ?>
                </button>
                <br><br>
            <?php } ?>
        </div>
    </form>
    <hr>            
    <?php if (isset($result_alunos) && $result_alunos->num_rows > 0) { ?>
        <h3>Notas para a Turma: <?php echo $turma_numero; ?></h3>

        <form class="mt-4" method="POST" action="cadastrar_notas_globais.php">
            <input type="hidden" name="turma_numero" value="<?php echo $turma_numero; ?>">
            
            <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark text-center">
                <tr>
                    <th>Aluno</th>
                    <th>AIS</th>
                    <th>Mostra de Ciências</th>
                    <th>PPI</th>
                    <th>Nota Exame</th>
                </tr>
                <tbody>
                <?php while ($aluno = $result_alunos->fetch_assoc()) { 
                    $aluno_id = $aluno['numero_matricula'];
                    $nota_atual = isset($notas_cadastradas[$aluno_id]) ? $notas_cadastradas[$aluno_id] : ['ais' => 0, 'mostra_ciencias' => 0, 'ppi' => 0, 'nota_exame' => 0];
                ?>
                    <tr>
                        <td><?php echo $aluno['nome']; ?></td>
                        <td><input class="form-control nota-input" type="number" step="0.01" name="alunos[<?php echo $aluno_id; ?>][ais]" min="0" max="10" value="<?php echo isset($nota_atual['ais']) ? number_format($nota_atual['ais'], 2, '.', '') : '0.00'; ?>" ></td>
<td><input class="form-control nota-input" type="number" step="0.01" name="alunos[<?php echo $aluno_id; ?>][mostra_ciencias]" min="0" max="10" value="<?php echo isset($nota_atual['mostra_ciencias']) ? number_format($nota_atual['mostra_ciencias'], 2, '.', '') : '0.00'; ?>"></td>
<td><input class="form-control nota-input" type="number" step="0.01" name="alunos[<?php echo $aluno_id; ?>][ppi]" min="0" max="10" value="<?php echo isset($nota_atual['ppi']) ? number_format($nota_atual['ppi'], 2, '.', '') : '0.00'; ?>" ></td>
<td><input class="form-control nota-input" type="number" step="0.01" name="alunos[<?php echo $aluno_id; ?>][nota_exame]" min="0" max="10" value="<?php echo isset($nota_atual['nota_exame']) ? number_format($nota_atual['nota_exame'], 2, '.', '') : '0.00'; ?>"></td>

                    </tr>
                <?php } ?>
                <tbody>

            </table>
            <br>
            <div class="text-end mt-3">
        <button type="submit" class="btn btn-success btn-sm">
            <i class="fas fa-save"></i> Salvar Notas
        </button>
    </div>        </form>
    <?php } ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Função para formatar o valor com 2 casas decimais
    function formatarNota(input) {
        let valor = parseFloat(input.value);
        
        if (!isNaN(valor)) {
            // Formata o número para duas casas decimais
            input.value = valor.toFixed(2);
        } else {
            input.value = '0.00';  // Caso o valor não seja um número, define 0.00
        }
    }

    // Adiciona o evento de 'blur' a todos os campos de notas
    document.querySelectorAll('.nota-input').forEach(function(input) {
        input.addEventListener('blur', function() {
            formatarNota(input);
        });
    });
</script>

</body>
</html>
