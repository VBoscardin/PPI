<?php
// Iniciar a sessão
session_start();

// Verificar se o usuário está autenticado e é um administrador
if (!isset($_SESSION['email']) || $_SESSION['user_type'] !== 'administrador') {
    header("Location: f_login.php");
    exit();
}

// Incluir as configurações e a conexão com o banco de dados
include_once 'config.php';

// Incluir o FPDF
require_once('fpdf/fpdf.php');

// Definir a classe FPDF para gerar o slide
class PDF extends FPDF {
    // Cabeçalho
    function Header() {
        // Definir fonte (garantir o uso da fonte que suporta UTF-8)
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, utf8_decode('Boletim de Notas'), 0, 1, 'C');
    }

    // Rodapé
    function Footer() {
        // Posicionar a 1.5 cm do final
        $this->SetY(-15);
        // Definir fonte
        $this->SetFont('Arial', 'I', 8);
        // Número da página
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo(), 0, 0, 'C');
    }

    // Tabela de notas com nome da disciplina
    function TabelaNotas($notas) {
        // Definir fontes (Arial suporta UTF-8)
        $this->SetFont('Arial', 'B', 10);

        // Cabeçalhos da tabela
        $this->Cell(40, 10, utf8_decode('Disciplina'), 1);  // Aumentando a largura da coluna 'Disciplina'
        $this->Cell(30, 10, utf8_decode('Parcial 1'), 1);    // Diminuindo a largura da coluna 'Parcial 1'
        $this->Cell(30, 10, utf8_decode('Ais'), 1);          // Ajustando as outras colunas conforme necessário
        $this->Cell(30, 10, utf8_decode('Semestre 1'), 1);
        $this->Cell(30, 10, utf8_decode('Parcial 2'), 1);
        $this->Cell(30, 10, utf8_decode('Mostra Ciências'), 1);
        $this->Cell(30, 10, utf8_decode('PPI'), 1);          // Diminuindo a largura da coluna 'PPI'
        $this->Cell(30, 10, utf8_decode('Semestre 2'), 1);
        $this->Cell(30, 10, utf8_decode('Nota Final'), 1);
        $this->Ln();


        // Adicionar as notas
        foreach ($notas as $nota) {
            $this->Cell(40, 10, utf8_decode($nota['disciplina']), 1);
            $this->Cell(30, 10, utf8_decode($nota['parcial_1']), 1);
            $this->Cell(30, 10, utf8_decode($nota['ais']), 1);
            $this->Cell(30, 10, utf8_decode($nota['nota_semestre_1']), 1);
            $this->Cell(30, 10, utf8_decode($nota['parcial_2']), 1);
            $this->Cell(30, 10, utf8_decode($nota['mostra_ciencias']), 1);
            $this->Cell(30, 10, utf8_decode($nota['ppi']), 1);
            $this->Cell(30, 10, utf8_decode($nota['nota_semestre_2']), 1);
            $this->Cell(30, 10, utf8_decode($nota['nota_final']), 1);
            $this->Ln();
        }
    }

    // Ajustar o posicionamento da imagem
function ExibirFoto($foto) {
    if ($foto) {
        // Verificar se a foto existe
        $caminho_foto = 'uploads/' . ltrim($foto, 'uploads/');

        // Verifique se o arquivo existe antes de tentar exibi-lo
        if (file_exists($caminho_foto)) {
            $largura = 30;  // largura em mm
            $altura = 30;   // altura em mm

            // Calcular a posição da foto
            $x = 10; // Posição X (horizontal)
            $y = 30; // Posição Y (vertical)

            // Exibir a imagem ajustada
            $this->Image($caminho_foto, $x, $y, $largura, $altura);
        } else {
            // Caso a foto não exista, exibe uma imagem padrão ou um aviso
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, utf8_decode('Imagem não disponível'), 0, 1, 'C');
        }
    } else {
        // Caso não haja foto, exibe um aviso
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Sem foto'), 0, 1, 'C');
    }
}

    

}

// Verificar se foi enviado o ID da turma para gerar o boletim
if (isset($_GET['turma_id'])) {
    $turma_id = $_GET['turma_id'];

    // Alterar a consulta para refletir a relação entre discentes, turmas e disciplinas
    $query = "
    SELECT d.numero_matricula, d.nome, d.foto, dis.nome AS disciplina_nome, n.parcial_1, n.ais, n.nota_semestre_1, 
           n.parcial_2, n.mostra_ciencias, n.ppi, n.nota_semestre_2, n.faltas, n.observacoes, n.nota_final
    FROM discentes d
    LEFT JOIN discentes_turmas dt ON d.numero_matricula = dt.numero_matricula
    LEFT JOIN notas n ON d.numero_matricula = n.discente_id
    LEFT JOIN disciplinas dis ON n.disciplina_id = dis.id
    WHERE dt.turma_numero = ? 
    ORDER BY d.nome ASC  -- Ordenar por nome do aluno de A a Z
";


    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $turma_id); // Bind da variável turma_id
    $stmt->execute();
    $stmt->bind_result($numero_matricula, $nome, $foto, $disciplina_nome, $parcial_1, $ais, $nota_semestre_1, $parcial_2, 
                       $mostra_ciencias, $ppi, $nota_semestre_2, $faltas, $observacoes, $nota_final);

    // Criar o PDF em formato paisagem (landscape)
    $pdf = new PDF('L', 'mm', 'A4');  // 'L' define a orientação como paisagem
    $pdf->AddPage();

    // Definir a fonte para o texto em UTF-8
    $pdf->SetFont('Arial', '', 12);  // Fonte Arial já suporta UTF-8

    // Gerar PDF para cada aluno
    $notasAluno = [];
    $alunoAnterior = null;

    while ($stmt->fetch()) {
        if ($alunoAnterior !== $nome) {
            // Se for um novo aluno, gerar a página para o aluno anterior (se houver)
            if ($alunoAnterior !== null) {
                $pdf->AddPage(); // Adiciona uma nova página para o aluno
                // Exibir foto e informações do aluno
                $pdf->SetFont('Arial', 'B', 14);
                $pdf->Cell(0, 10, utf8_decode('Aluno: ') . utf8_decode($alunoAnterior), 0, 1, 'C');
                $pdf->Ln();
    
                // Exibir foto do aluno
                $pdf->ExibirFoto($foto);
                $pdf->Ln(40); // Ajustar o espaçamento após a imagem
    
                // Exibir a tabela de notas
                $pdf->TabelaNotas($notasAluno);
    
                // Exibir faltas e observações
                $pdf->Ln();
                $pdf->Cell(0, 10, utf8_decode('Faltas: ') . utf8_decode($faltas), 0, 1);
                $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes));
            }
    
            // Resetar as notas para o novo aluno
            $notasAluno = [];
            $alunoAnterior = $nome;
        }
    
        // Adicionar as notas do aluno
        $notasAluno[] = [
            'disciplina' => $disciplina_nome,
            'parcial_1' => $parcial_1,
            'ais' => $ais,
            'nota_semestre_1' => $nota_semestre_1,
            'parcial_2' => $parcial_2,
            'mostra_ciencias' => $mostra_ciencias,
            'ppi' => $ppi,
            'nota_semestre_2' => $nota_semestre_2,
            'nota_final' => $nota_final
        ];
    }
    
    // Gerar a última página para o último aluno
    if ($alunoAnterior !== null) {
        $pdf->AddPage();
        // Exibir foto e informações do aluno
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 10, utf8_decode('Aluno: ') . utf8_decode($alunoAnterior), 0, 1, 'C');
        $pdf->Ln();
    
        // Exibir foto do aluno
        $pdf->ExibirFoto($foto);
        $pdf->Ln(40); // Ajustar o espaçamento após a imagem
    
        // Exibir a tabela de notas
        $pdf->TabelaNotas($notasAluno);
    
        // Exibir faltas e observações
        $pdf->Ln();
        $pdf->Cell(0, 10, utf8_decode('Faltas: ') . utf8_decode($faltas), 0, 1);
        $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes));
    }
    

    // Fechar a conexão
    $stmt->close();

    // Gerar o arquivo PDF e forçar o download
    $pdf->Output('D', 'boletins_turma_' . $turma_id . '.pdf');  // 'D' força o download do PDF
    exit();
}

// Alterar a consulta para refletir o nome correto da coluna "numero" na tabela turmas
$query = "SELECT numero FROM turmas"; 
$stmt = $conn->prepare($query);
$stmt->execute();
$stmt->bind_result($turma_numero);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerar Boletins</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h1>Selecione uma Turma para Gerar Boletins</h1>
    
    <!-- Tabela com as turmas -->
    <table border="1">
        <thead>
            <tr>
                <th>Nome da Turma</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($stmt->fetch()) { ?>
                <tr>
                    <td><?php echo utf8_decode($turma_numero); ?></td>
                    <td>
                        <!-- Botão para gerar o boletim da turma -->
                        <form action="" method="get">
                            <input type="hidden" name="turma_id" value="<?php echo $turma_numero; ?>">
                            <button type="submit">Gerar Boletim</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

</body>
</html>

<?php
// Fechar a conexão
$stmt->close();
?>
