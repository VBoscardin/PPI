<?php
// Incluir as configurações e a conexão com o banco de dados
include_once 'config.php';

// Se o download do PDF de todos os alunos for solicitado
if (isset($_GET['download_all_pdf']) && $_GET['download_all_pdf'] === 'true' && isset($_GET['numero_turma']) && isset($_GET['ano_turma'])) {
    // Incluir o FPDF
    require_once('fpdf/fpdf.php');

    // Obter os dados da turma
    $numero_turma = $_GET['numero_turma'];
    $ano_turma = $_GET['ano_turma'];

    // Consultar os discentes dessa turma
    $query_discentes = "
    SELECT d.numero_matricula, d.nome, d.email, d.cidade
    FROM discentes_turmas dt
    JOIN discentes d ON dt.numero_matricula = d.numero_matricula
    WHERE dt.turma_numero = ? AND dt.turma_ano = ?
    ORDER BY d.nome ASC
";

    $stmt_discentes = $conn->prepare($query_discentes);
    $stmt_discentes->bind_param('ii', $numero_turma, $ano_turma);
    $stmt_discentes->execute();
    $result_discentes = $stmt_discentes->get_result();

    // Criar o PDF
    $pdf = new FPDF();
    $pdf->SetFont('Arial', '', 12);

    // Para cada discente, gerar uma página com o boletim
    while ($discente = $result_discentes->fetch_assoc()) {
        // Consultar as notas do discente
        $numero_matricula = $discente['numero_matricula'];
        $query_boletim_pdf = "
        SELECT n.nota_final, n.nota_exame, n.parcial_1, n.nota_semestre_1, n.parcial_2, n.nota_semestre_2, 
        n.faltas, n.observacoes, d.nome AS disciplina_nome
 FROM notas n
 JOIN disciplinas d ON n.disciplina_id = d.id
 WHERE n.discente_id = ?
 ORDER BY d.nome ASC
 
        ";
        $stmt_boletim_pdf = $conn->prepare($query_boletim_pdf);
        $stmt_boletim_pdf->bind_param('i', $numero_matricula);
        $stmt_boletim_pdf->execute();
        $result_boletim_pdf = $stmt_boletim_pdf->get_result();

        // Adicionar uma página para o aluno
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Boletim do Discente: ' . $discente['nome'], 0, 1, 'C');
        $pdf->Ln(10); // Adiciona um espaçamento

        // Definir largura das colunas para a tabela
        $col_widths = [50, 25, 25, 25, 25, 25, 25, 25, 40]; // Ajustado para evitar corte
        $pdf->SetFont('Arial', 'B', 12);

        // Adicionando o cabeçalho da tabela
        $pdf->SetFillColor(200, 220, 255); // Cor de fundo azul claro
        $pdf->Cell($col_widths[0], 10, 'Disciplina', 1, 0, 'C', true);
        $pdf->Cell($col_widths[1], 10, 'Parcial 1', 1, 0, 'C', true);
        $pdf->Cell($col_widths[2], 10, 'Nota Sem. 1', 1, 0, 'C', true);
        $pdf->Cell($col_widths[3], 10, 'Parcial 2', 1, 0, 'C', true);
        $pdf->Cell($col_widths[4], 10, 'Nota Sem. 2', 1, 0, 'C', true);
        $pdf->Cell($col_widths[5], 10, 'Nota Final', 1, 0, 'C', true);
        $pdf->Cell($col_widths[6], 10, 'Nota Exame', 1, 0, 'C', true);
        $pdf->Cell($col_widths[7], 10, 'Faltas', 1, 0, 'C', true);
        $pdf->Cell($col_widths[8], 10, 'Observações', 1, 1, 'C', true);

        // Preenchendo as linhas com os dados do boletim
        $pdf->SetFont('Arial', '', 12);
        while ($boletim = $result_boletim_pdf->fetch_assoc()) {
            $pdf->Cell($col_widths[0], 10, utf8_decode($boletim['disciplina_nome']), 1, 0, 'C');
            $pdf->Cell($col_widths[1], 10, utf8_decode($boletim['parcial_1']), 1, 0, 'C');
            $pdf->Cell($col_widths[2], 10, utf8_decode($boletim['nota_semestre_1']), 1, 0, 'C');
            $pdf->Cell($col_widths[3], 10, utf8_decode($boletim['parcial_2']), 1, 0, 'C');
            $pdf->Cell($col_widths[4], 10, utf8_decode($boletim['nota_semestre_2']), 1, 0, 'C');
            $pdf->Cell($col_widths[5], 10, ($boletim['nota_final'] !== null ? utf8_decode($boletim['nota_final']) : 'N/A'), 1, 0, 'C');
            $pdf->Cell($col_widths[6], 10, ($boletim['nota_exame'] !== null ? utf8_decode($boletim['nota_exame']) : 'N/A'), 1, 0, 'C');
            $pdf->Cell($col_widths[7], 10, utf8_decode($boletim['faltas']), 1, 0, 'C');
            $pdf->MultiCell($col_widths[8], 10, utf8_decode($boletim['observacoes']), 1, 'C');
        }

        $stmt_boletim_pdf->close();
    }

    $stmt_discentes->close();

    // Finalizar e gerar o PDF para download
    $pdf->Output('D', 'boletins_turma_' . $numero_turma . '_' . $ano_turma . '.pdf');  // 'D' significa download
    exit;  // Evitar que o restante do HTML seja exibido após o PDF ser gerado
}

// Se o download do PDF individual do aluno for solicitado
if (isset($_GET['download_pdf']) && isset($_GET['numero_matricula'])) {
    require_once('fpdf/fpdf.php');
    
    // Obter a matrícula do discente
    $numero_matricula = $_GET['numero_matricula'];
    
    // Consultar os dados do boletim do aluno
    $query_boletim_pdf = "
        SELECT n.nota_final, n.nota_exame, n.parcial_1, n.nota_semestre_1, n.parcial_2, n.nota_semestre_2, 
               n.faltas, n.observacoes, d.nome AS disciplina_nome
        FROM notas n
        JOIN disciplinas d ON n.disciplina_id = d.id
        WHERE n.discente_id = ?
        ORDER BY d.nome ASC
    ";
    $stmt_boletim_pdf = $conn->prepare($query_boletim_pdf);
    $stmt_boletim_pdf->bind_param('i', $numero_matricula);
    $stmt_boletim_pdf->execute();
    $result_boletim_pdf = $stmt_boletim_pdf->get_result();

    // Criar o PDF para o aluno
    $pdf = new FPDF();
    $pdf->SetFont('Arial', '', 12);

    // Adicionar uma página para o boletim
    $pdf->AddPage();
    
    // Consultar o nome do aluno
    $query_nome_aluno = "SELECT nome FROM discentes WHERE numero_matricula = ?";
    $stmt_nome = $conn->prepare($query_nome_aluno);
    $stmt_nome->bind_param('i', $numero_matricula);
    $stmt_nome->execute();
    $result_nome = $stmt_nome->get_result();
    $aluno = $result_nome->fetch_assoc();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Boletim do Discente: ' . $aluno['nome'], 0, 1, 'C');
    $pdf->Ln(10);

    // Definir largura das colunas para a tabela
    $col_widths = [50, 25, 25, 25, 25, 25, 25, 25, 40]; // Ajustado para evitar corte
    $pdf->SetFont('Arial', 'B', 12);

    // Adicionando o cabeçalho da tabela
    $pdf->SetFillColor(200, 220, 255);
    $pdf->Cell($col_widths[0], 10, 'Disciplina', 1, 0, 'C', true);
    $pdf->Cell($col_widths[1], 10, 'Parcial 1', 1, 0, 'C', true);
    $pdf->Cell($col_widths[2], 10, 'Nota Sem. 1', 1, 0, 'C', true);
    $pdf->Cell($col_widths[3], 10, 'Parcial 2', 1, 0, 'C', true);
    $pdf->Cell($col_widths[4], 10, 'Nota Sem. 2', 1, 0, 'C', true);
    $pdf->Cell($col_widths[5], 10, 'Nota Final', 1, 0, 'C', true);
    $pdf->Cell($col_widths[6], 10, 'Nota Exame', 1, 0, 'C', true);
    $pdf->Cell($col_widths[7], 10, 'Faltas', 1, 0, 'C', true);
    $pdf->Cell($col_widths[8], 10, 'Observações', 1, 1, 'C', true);

    // Preenchendo as linhas com os dados do boletim
    $pdf->SetFont('Arial', '', 12);
    while ($boletim = $result_boletim_pdf->fetch_assoc()) {
        $pdf->Cell($col_widths[0], 10, utf8_decode($boletim['disciplina_nome']), 1, 0, 'C');
        $pdf->Cell($col_widths[1], 10, utf8_decode($boletim['parcial_1']), 1, 0, 'C');
        $pdf->Cell($col_widths[2], 10, utf8_decode($boletim['nota_semestre_1']), 1, 0, 'C');
        $pdf->Cell($col_widths[3], 10, utf8_decode($boletim['parcial_2']), 1, 0, 'C');
        $pdf->Cell($col_widths[4], 10, utf8_decode($boletim['nota_semestre_2']), 1, 0, 'C');
        $pdf->Cell($col_widths[5], 10, ($boletim['nota_final'] !== null ? utf8_decode($boletim['nota_final']) : 'N/A'), 1, 0, 'C');
        $pdf->Cell($col_widths[6], 10, ($boletim['nota_exame'] !== null ? utf8_decode($boletim['nota_exame']) : 'N/A'), 1, 0, 'C');
        $pdf->Cell($col_widths[7], 10, utf8_decode($boletim['faltas']), 1, 0, 'C');
        $pdf->MultiCell($col_widths[8], 10, utf8_decode($boletim['observacoes']), 1, 'C');
    }

    // Finalizar e gerar o PDF para download
    $pdf->Output('D', 'boletim_individual_' . $numero_matricula . '.pdf');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boletim dos Discentes</title>
</head>
<body>
    <?php
    // Exibição de turmas (não alterada)
    $query_turmas = "
        SELECT t.numero, t.ano, c.nome AS curso_nome
        FROM turmas t
        JOIN cursos c ON t.curso_id = c.id
        ORDER BY t.ano DESC, t.numero ASC
    ";
    $result_turmas = $conn->query($query_turmas);

    if ($result_turmas->num_rows > 0) {
        echo "<h1>Selecione uma Turma</h1>";
        echo "<ul>";

        // Exibir lista de turmas
        while ($turma = $result_turmas->fetch_assoc()) {
            echo "<li><a href='gerar_boletim.php?numero_turma=" . $turma['numero'] . "&ano_turma=" . $turma['ano'] . "'>Turma " . $turma['numero'] . " - " . $turma['curso_nome'] . " (" . $turma['ano'] . ")</a> 
                    <a href='gerar_boletim.php?download_all_pdf=true&numero_turma=" . $turma['numero'] . "&ano_turma=" . $turma['ano'] . "'>Gerar PDF Todos</a></li>";
        }

        echo "</ul>";
    } else {
        echo "<p>Nenhuma turma cadastrada.</p>";
    }

    // Exibição de discentes
    if (isset($_GET['numero_turma']) && isset($_GET['ano_turma'])) {
        // Consultar os discentes dessa turma
        $numero_turma = $_GET['numero_turma'];
        $ano_turma = $_GET['ano_turma'];

        $query_discentes = "
            SELECT d.numero_matricula, d.nome, d.email, d.cidade
            FROM discentes_turmas dt
            JOIN discentes d ON dt.numero_matricula = d.numero_matricula
            WHERE dt.turma_numero = ? AND dt.turma_ano = ?
        ";
        $stmt_discentes = $conn->prepare($query_discentes);
        $stmt_discentes->bind_param('ii', $numero_turma, $ano_turma);
        $stmt_discentes->execute();
        $result_discentes = $stmt_discentes->get_result();

        if ($result_discentes->num_rows > 0) {
            echo "<h2>Discentes da Turma " . $numero_turma . " - Ano " . $ano_turma . "</h2>";
            echo "<table border='1' cellpadding='10'>
                    <tr>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Cidade</th>
                        <th>Ações</th>
                    </tr>";

            while ($discente = $result_discentes->fetch_assoc()) {
                echo "<tr>
                        <td>" . $discente['nome'] . "</td>
                        <td>" . $discente['email'] . "</td>
                        <td>" . $discente['cidade'] . "</td>
                        <td><a href='gerar_boletim.php?download_pdf=true&numero_matricula=" . $discente['numero_matricula'] . "'>Gerar PDF</a></td>
                      </tr>";
            }

            echo "</table>";
        } else {
            echo "<p>Nenhum discente encontrado para esta turma.</p>";
        }

        $stmt_discentes->close();
    }
    ?>
</body>
</html>
