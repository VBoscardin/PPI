<?php
session_start();
include 'config.php'; // Arquivo de conexão com o banco

// Obtém setores do banco de dados
$query = "SELECT * FROM setores";
$result = $conn->query($query);
$setores = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["setor_id"])) {
    $id = $_POST["setor_id"];
    $nome = $_POST["nome"];
    $local = $_POST["local"];
    $email = $_POST["email"];
    $nova_senha = trim($_POST["nova_senha"]);

    // Atualiza os dados do setor na tabela "setores"
    $sql_edit = "UPDATE setores SET nome = ?, local = ?, email = ? WHERE id = ?";
    $stmt_edit = $conn->prepare($sql_edit);

    if ($stmt_edit) {
        $stmt_edit->bind_param("sssi", $nome, $local, $email, $id);
        
        if ($stmt_edit->execute()) {
            // Verificar se o setor tem um ussession_start();
include 'config.php'; // Conexão com o banco

// Obtém setores do banco de dados
$query = "SELECT * FROM setores";
$result = $conn->query($query);
$setores = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["setor_id"])) {
    $id = $_POST["setor_id"];
    $nome = $_POST["nome"];
    $local = $_POST["local"];
    $email = $_POST["email"];
    $nova_senha = trim($_POST["nova_senha"]);

    // Atualiza os dados do setor na tabela "setores"
    $sql_edit = "UPDATE setores SET nome = ?, local = ?, email = ? WHERE id = ?";
    $stmt_edit = $conn->prepare($sql_edit);

    if ($stmt_edit) {
        $stmt_edit->bind_param("sssi", $nome, $local, $email, $id);
        
        if ($stmt_edit->execute()) {
            // **Busca o ID correto do usuário correspondente ao setor**
            $stmt_check = $conn->prepare("SELECT id FROM usuarios WHERE tipo = 'setor' AND email = ?");
            $stmt_check->bind_param("s", $email); // Usa o email como critério
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0 && !empty($nova_senha)) {
                // Pega o ID do usuário
                $usuario = $result_check->fetch_assoc();
                $usuario_id = $usuario['id'];

                // Atualizar a senha na tabela "usuarios"
                $senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
                $stmt_senha = $conn->prepare("UPDATE usuarios SET password_hash = ? WHERE id = ?");
                $stmt_senha->bind_param("si", $senha_hash, $usuario_id);

                if (!$stmt_senha->execute()) {
                    $_SESSION['msg'] = "Erro ao atualizar a senha.";
                    $_SESSION['msg_type'] = "danger";
                    header("Location: listar_setores.php");
                    exit();
                }
                $stmt_senha->close();
            }

            $_SESSION['msg'] = "Setor atualizado com sucesso!";
            $_SESSION['msg_type'] = "success";
        } else {
            $_SESSION['msg'] = "Erro ao atualizar o setor!";
            $_SESSION['msg_type'] = "danger";
        }
        
        $stmt_edit->close();
    } else {
        $_SESSION['msg'] = "Erro ao preparar consulta para atualizar setor.";
        $_SESSION['msg_type'] = "danger";
    }

    $conn->close();
    header("Location: listar_setores.php");
    exit();
}

// Excluir setor
if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $stmt = $conn->prepare("DELETE FROM setores WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $_SESSION['msg'] = "Setor excluído!";
        $_SESSION['msg_type'] = "danger";
    } else {
        $_SESSION['msg'] = "Erro ao excluir o setor!";
        $_SESSION['msg_type'] = "danger";
    }

    $stmt->close();
    $conn->close();

    header("Location: listar_setores.php");
    exit();
}
        }
    }
}


?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Listar Setores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-3 sidebar">
                <div class="separator mb-3"></div>
                <div class="signe-text">SIGNE</div>
                <div class="separator mt-3 mb-3"></div>
                <button onclick="location.href='f_pagina_adm.php'">
                    <i class="fas fa-home"></i> Início
                </button>
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#expandable-menu" aria-expanded="false" aria-controls="expandable-menu">
                    <i id="toggle-icon" class="fas fa-plus"></i> Cadastrar
                </button>
                <div id="expandable-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='cadastrar_adm.php'">
                            <i class="fas fa-plus"></i> Cadastrar Administrador
                        </button>
                        <button onclick="location.href='cadastrar_curso.php'">
                            <i class="fas fa-plus"></i> Cadastrar Curso
                        </button>
                        <button onclick="location.href='cadastrar_disciplina.php'">
                            <i class="fas fa-plus"></i> Cadastrar Disciplina
                        </button>
                        <button onclick="location.href='cadastrar_docente.php'">
                            <i class="fas fa-plus"></i> Cadastrar Docente
                        </button>
                        <button onclick="location.href='cadastrar_setor.php'">
                            <i class="fas fa-plus"></i> Cadastrar Setor
                        </button>
                        <button onclick="location.href='cadastrar_turma.php'">
                            <i class="fas fa-plus"></i> Cadastrar Turma
                        </button>
                    </div>
                </div>
                <button onclick="location.href='gerar_boletim.php'">
                    <i class="fas fa-file-alt"></i> Gerar Boletim
                </button>
                <button onclick="location.href='gerar_slide.php'">
                    <i class="fas fa-sliders-h"></i> Gerar Slide Pré Conselho
                </button>
                
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#list-menu" aria-expanded="false" aria-controls="list-menu">
                    <i id="toggle-icon" class="fas fa-list"></i> Listar
                </button>

                <div id="list-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='listar_administradores.php'">
                            <i class="fas fa-list"></i> Administradores
                        </button>
                        <button onclick="location.href='listar_cursos.php'">
                            <i class="fas fa-list"></i> Cursos
                        </button>
                        <button onclick="location.href='listar_discentes.php'">
                            <i class="fas fa-list"></i> Discentes
                        </button>
                        <button onclick="location.href='listar_disciplinas.php'">
                            <i class="fas fa-list"></i> Disciplinas
                        </button>
                        <button onclick="location.href='listar_docentes.php'">
                            <i class="fas fa-list"></i> Docentes
                        </button>
                        <button onclick="location.href='listar_setores.php'">
                            <i class="fas fa-list"></i> Setores
                        </button>
                        <button onclick="location.href='listar_turmas.php'">
                            <i class="fas fa-list"></i> Turmas
                        </button>
                    </div>
                </div>
                <button class="btn btn-danger" onclick="location.href='sair.php'">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>

            <div class="col-md-9 main-content">
                <div class="container">
                    <div class="header-container">
                        <img src="imgs/iffar.png" alt="Logo do IFFAR" class="logo">
                        <div class="title ms-3">Listar Setores</div>
                    </div>
                </div>
                
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-md-12">
                        <?php
                            if (isset($_SESSION['msg'])) {
                                $msg = $_SESSION['msg'];
                                $msg_type = $_SESSION['msg_type'];
                                echo "<div class='alert alert-$msg_type alert-dismissible fade show' role='alert'>
                                        $msg
                                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                                      </div>";
                                unset($_SESSION['msg']); // Limpar a mensagem após exibição
                            }
                            ?>
                            <div class="card">
                                <div class="card-body">
                                    <table class="table table-bordered table-hover table-sm align-middle">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Nome</th>
                                                <th>Local</th>
                                                <th>Email</th>
                                                <th>Senha</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            // Verificar se há setores
                                            if (count($setores) > 0) {
                                                foreach ($setores as $setor) {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($setor['nome']); ?></td>
                                                        <td><?php echo htmlspecialchars($setor['local']); ?></td>
                                                        <td><?php echo htmlspecialchars($setor['email']); ?></td>
                                                        <td></td>
                                                        <td class="text-center">
                                                            <div class="d-flex gap-2 justify-content-center">                            
                                                                <!-- Botões Editar e Excluir -->
                                                                <button class="btn btn-warning btn-sm custom-btn" onclick="editSetor(<?php echo $setor['id']; ?>)">
                                                                    <i class="fas fa-edit me-2"></i> Editar
                                                                </button>
                                                                <a href="listar_setores.php?delete=<?php echo $setor['id']; ?>" class="btn btn-danger btn-sm custom-btn">
                                                                    <i class="fas fa-trash-alt me-2"></i> Excluir
                                                                </a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    
                                                    <!-- Modal de Edição -->
                                                    <div class="modal fade" id="editSetorModal" tabindex="-1" aria-labelledby="editSetorModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="editSetorModalLabel">Editar Setor</h5>
                                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <form method="POST" action="listar_setores.php">
                                                                        <input type="hidden" id="setor_id" name="setor_id">
                                                                        <div class="mb-3">
                                                                            <label for="nome" class="form-label">Nome</label>
                                                                            <input type="text" class="form-control" id="nome" name="nome" required>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="local" class="form-label">Local</label>
                                                                            <input type="text" class="form-control" id="local" name="local" required>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="email" class="form-label">Email</label>
                                                                            <input type="email" class="form-control" id="email" name="email" required>
                                                                        </div>
                                                                        <div class="mb-3">
                                                                            <label for="senha" class="form-label">Senha</label>
                                                                            <input type="password" class="form-control" id="nova_senha" name="nova_senha">
                                                                            <small class="text-muted">Deixe em branco para não alterar a senha.</small>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                                                            <button type="submit" class="btn btn-primary">Salvar mudanças</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                            } else {
                                                echo "<tr><td colspan='5'>Nenhum setor encontrado.</td></tr>";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function editSetor(id) {
            // Buscar o setor com o ID fornecido
            var setor = <?php echo json_encode($setores); ?>.find(function(setor) {
                return setor.id == id;
            });

            // Preencher o modal com as informações do setor
            document.getElementById('setor_id').value = setor.id;
            document.getElementById('nome').value = setor.nome;
            document.getElementById('local').value = setor.local;
            document.getElementById('email').value = setor.email;

            // Mostrar o modal
            var myModal = new bootstrap.Modal(document.getElementById('editSetorModal'));
            myModal.show();
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>