<?php
$servername = "localhost";
$database = "bd_ppi";
$username = "root";
$password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
?>
