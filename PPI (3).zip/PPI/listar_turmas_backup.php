<?php
// Iniciar a sessão
session_start();


// Verificar se o usuário está autenticado e é um administrador
if (!isset($_SESSION['email']) || $_SESSION['user_type'] !== 'administrador') {
    header("Location: f_login.php");
    exit();
}


// Incluir as configurações e a conexão com o banco de dados
include_once 'config.php';


// Obter o nome e a foto do perfil do administrador
$stmt = $conn->prepare("SELECT username, foto_perfil FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$stmt->bind_result($nome, $foto_perfil);
$stmt->fetch();
$stmt->close();


// Incluir o FPDF
require_once('fpdf/fpdf.php');


// Definir a classe FPDF para gerar o slide
class PDF extends FPDF {
    // Cabeçalho
    function Header() {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, utf8_decode('Slide de Notas'), 0, 1, 'C');
    }

    // Rodapé
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo(), 0, 0, 'C');
    }

   // Método para exibir a tabela de notas
function TabelaNotas($notas) {
    $this->SetFont('Arial', 'B', 8); // Fonte menor para ajustar na página
    $altura_celula = 8; // Altura menor para as células

    // Definir a posição horizontal para a direita
    $this->SetX(100);  // Ajuste a posição X para a direita

    // Cabeçalhos - ajustar a largura das células
    $this->Cell(30, $altura_celula, utf8_decode('Disciplina'), 1, 0, 'C');  // Reduzido para 40
    $this->Cell(15, $altura_celula, utf8_decode('Parc. 1'), 1, 0, 'C');          // Reduzido para 15
    $this->Cell(15, $altura_celula, utf8_decode('AIS'), 1, 0, 'C');          // Reduzido para 15
    $this->Cell(25, $altura_celula, utf8_decode('Semestre 1'), 1, 0, 'C'); // Reduzido para 25
    $this->Cell(15, $altura_celula, utf8_decode('Parc. 2'), 1, 0, 'C');          // Reduzido para 15
    $this->Cell(25, $altura_celula, utf8_decode('Mostra Ciências'), 1, 0, 'C'); // Reduzido para 25
    $this->Cell(15, $altura_celula, utf8_decode('PPI'), 1, 0, 'C');          // Reduzido para 15
    $this->Cell(25, $altura_celula, utf8_decode('Semestre 2'), 1, 0, 'C'); // Reduzido para 25
    $this->Cell(15, $altura_celula, utf8_decode('Nota Final'), 1, 1, 'C');     // Reduzido para 15

    $this->SetFont('Arial', '', 8); // Fonte menor para ajustar na página

    foreach ($notas as $nota) {
        // Mover a tabela para a direita
        $this->SetX(100);  // Ajuste a posição X para a direita

        $this->Cell(30, $altura_celula, utf8_decode($nota['disciplina']), 1, 0, 'C');  // Reduzido para 40
        $this->Cell(15, $altura_celula, $nota['parcial_1'], 1, 0, 'C');          // Reduzido para 15
        $this->Cell(15, $altura_celula, $nota['ais'], 1, 0, 'C');          // Reduzido para 15
        $this->Cell(25, $altura_celula, $nota['nota_semestre_1'], 1, 0, 'C'); // Reduzido para 25
        $this->Cell(15, $altura_celula, $nota['parcial_2'], 1, 0, 'C');          // Reduzido para 15
        $this->Cell(25, $altura_celula, $nota['mostra_ciencias'], 1, 0, 'C'); // Reduzido para 25
        $this->Cell(15, $altura_celula, $nota['ppi'], 1, 0, 'C');          // Reduzido para 15
        $this->Cell(25, $altura_celula, $nota['nota_semestre_2'], 1, 0, 'C'); // Reduzido para 25
        $this->Cell(15, $altura_celula, $nota['nota_final'], 1, 1, 'C');     // Reduzido para 15
    }
}




    // Exibir a foto do aluno
    function ExibirFoto($foto) {
        if ($foto) {
            $caminho_foto = 'uploads/' . ltrim($foto, 'uploads/');
            if (file_exists($caminho_foto)) {
                $this->Image($caminho_foto, 10, 30, 30, 30);
            } else {
                $this->SetFont('Arial', 'I', 8);
                $this->Cell(0, 10, utf8_decode('Imagem não disponível'), 0, 1, 'C');
            }
        } else {
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, utf8_decode('Sem foto'), 0, 1, 'C');
        }
    }

    // Exibir as informações do aluno
    function ExibirInformacoesAluno($aluno) {
        $this->SetFont('Arial', 'B', 8); // Fonte menor
        $this->Ln(5);
        $this->Cell(0, 10, utf8_decode("Nome: " . $aluno['nome']), 0, 1);
        $this->SetFont('Arial', '', 8); // Fonte menor
        
        $this->Cell(0, 10, utf8_decode("Telefone: " . $aluno['telefone']), 0, 1);
        $this->Ln(5);

        // Informações adicionais do aluno
        $this->SetFont('Arial', 'B', 8);
$this->Cell(0, 10, utf8_decode("Informações Adicionais:"), 0, 1);
$this->SetFont('Arial', '', 8);

// Primeira linha com informações gerais
$this->Cell(0, 5, utf8_decode(
    "Reprovações: " . $aluno['reprovacoes'] . "  |  Acompanhamento: " . $aluno['acompanhamento'] . 
    "  |  Apoio Psicológico: " . $aluno['apoio_psicologico'] . "  |  Auxílio Permanência: " . $aluno['auxilio_permanencia']
), 0, 1);

// Segunda linha com mais detalhes
$this->Cell(0, 5, utf8_decode(
    "Cotista: " . $aluno['cotista'] . "  |  Estágio: " . $aluno['estagio'] . 
    "  |  Acompanhamento de Saúde: " . $aluno['acompanhamento_saude'] . 
    "  |  Projetos: Ensino(" . $aluno['projeto_ensino'] . ") | Pesquisa(" . $aluno['projeto_pesquisa'] . ") | Extensão(" . $aluno['projeto_extensao'] . ")"
), 0, 1);

$this->Ln(5);

    }

    // Prevenir quebra de página ao adicionar conteúdo
    function CheckPageBreak($altura) {
        if ($this->GetY() + $altura > 290) { // Evita ultrapassar o limite da página
            $this->AddPage();
        }
    }
}




// Verificar se foi enviado o ID da turma para gerar o boletim
if (isset($_GET['turma_id'])) {
    $turma_id = $_GET['turma_id'];


    // Alterar a consulta para refletir a relação entre discentes, turmas e disciplinas
    $query = "
    SELECT d.numero_matricula, d.nome, d.foto, d.uf, d.telefone, d.reprovacoes, d.acompanhamento, 
    d.apoio_psicologico, d.auxilio_permanencia, d.cotista, d.estagio, d.acompanhamento_saude, 
    d.projeto_pesquisa, d.projeto_extensao, d.projeto_ensino, d.morador, d.morador_detalhes, 
    d.deficiencia, d.deficiencia_detalhes, d.alergia, d.alergia_detalhes, 
    dis.nome AS disciplina_nome, 
    COALESCE(n.parcial_1, 0) AS parcial_1, COALESCE(n.ais, 0) AS ais, COALESCE(n.nota_semestre_1, 0) AS nota_semestre_1, 
    COALESCE(n.parcial_2, 0) AS parcial_2, COALESCE(n.mostra_ciencias, 0) AS mostra_ciencias, COALESCE(n.ppi, 0) AS ppi, 
    COALESCE(n.nota_semestre_2, 0) AS nota_semestre_2, COALESCE(n.faltas, 0) AS faltas, COALESCE(n.observacoes, '') AS observacoes, 
    COALESCE(n.nota_final, 0) AS nota_final
FROM discentes d
LEFT JOIN discentes_turmas dt ON d.numero_matricula = dt.numero_matricula
LEFT JOIN notas n ON d.numero_matricula = n.discente_id AND dt.turma_numero = n.turma_numero
LEFT JOIN disciplinas dis ON n.disciplina_id = dis.id
WHERE dt.turma_numero = ?
ORDER BY d.nome ASC;
";






    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $turma_id); // Bind da variável turma_id
    $stmt->execute();
    $stmt->bind_result(
        $numero_matricula, $nome, $foto, $uf, $telefone, $reprovacoes, 
        $acompanhamento, $apoio_psicologico, $auxilio_permanencia, $cotista, 
        $estagio, $acompanhamento_saude, $projeto_pesquisa, $projeto_extensao, 
        $projeto_ensino, $morador, $morador_detalhes, $deficiencia, $deficiencia_detalhes, 
        $alergia, $alergia_detalhes, $disciplina_nome, 
        $parcial_1, $ais, $nota_semestre_1, $parcial_2, 
        $mostra_ciencias, $ppi, $nota_semestre_2, $faltas, 
        $observacoes, $nota_final
    );
    


    // Criar o PDF em formato paisagem (landscape)
    $pdf = new PDF('L', 'mm', 'A4');  // 'L' define a orientação como paisagem
    $pdf->AddPage();


    // Definir a fonte para o texto em UTF-8
    $pdf->SetFont('Arial', '', 12);  // Fonte Arial já suporta UTF-8


    // Gerar PDF para cada aluno
$notasAluno = [];
$alunoAnterior = null;

while ($stmt->fetch()) {
    if ($alunoAnterior !== $nome) {
        if ($alunoAnterior !== null) {
            $pdf->AddPage();

            // Exibir foto e nome do aluno
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(0, 10, utf8_decode('Aluno: ') . utf8_decode($alunoAnterior), 0, 1, 'C');
            $pdf->Ln();

            // Exibir foto
            $pdf->ExibirFoto($foto);
            $pdf->Ln(40);

            // Exibir dados adicionais do aluno
            $pdf->SetFont('Arial', '', 10);
            $pdf->Cell(0, 10, utf8_decode("Reprovações: $reprovacoes"), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Acompanhamento: $acompanhamento | Apoio Psicológico: $apoio_psicologico"), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Auxílio Permanência: $auxilio_permanencia | Cotista: $cotista | Estágio: $estagio"), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Acompanhamento Saúde: $acompanhamento_saude | Pesquisa: $projeto_pesquisa | Extensão: $projeto_extensao | Ensino: $projeto_ensino"), 0, 1);

            // Informações de moradia, deficiência e alergia
// Informações de moradia, deficiência e alergia
$pdf->Cell(0, 10, utf8_decode("Morador: $morador " . ($morador === 'Sim' ? "($morador_detalhes)" : "")), 0, 1);
            
            $pdf->Ln(5);

            // Exibir a tabela de notas
            $pdf->TabelaNotas($notasAluno);

            // Exibir faltas e observações
            $pdf->Ln();
            $pdf->Cell(0, 10, utf8_decode('Faltas: ') . utf8_decode($faltas), 0, 1);
            $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes));
        }

        // Resetar as notas para o novo aluno
        $notasAluno = [];
        $alunoAnterior = $nome;
    }

    // Adicionar as notas do aluno
    $notasAluno[] = [
        'disciplina' => $disciplina_nome,
        'parcial_1' => $parcial_1,
        'ais' => $ais,
        'nota_semestre_1' => $nota_semestre_1,
        'parcial_2' => $parcial_2,
        'mostra_ciencias' => $mostra_ciencias,
        'ppi' => $ppi,
        'nota_semestre_2' => $nota_semestre_2,
        'nota_final' => $nota_final
    ];
}

// Gerar a última página para o último aluno
if ($alunoAnterior !== null) {
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, utf8_decode('Aluno: ') . utf8_decode($alunoAnterior), 0, 1, 'C');
    $pdf->Ln();

    // Exibir foto
    $pdf->ExibirFoto($foto);
    $pdf->Ln(40);

    // Exibir dados adicionais do aluno
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 10, utf8_decode("Reprovações: $reprovacoes"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Acompanhamento: $acompanhamento | Apoio Psicológico: $apoio_psicologico"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Auxílio Permanência: $auxilio_permanencia | Cotista: $cotista | Estágio: $estagio"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Acompanhamento Saúde: $acompanhamento_saude | Pesquisa: $projeto_pesquisa | Extensão: $projeto_extensao | Ensino: $projeto_ensino"), 0, 1);
// Informações de moradia, deficiência e alergia
$pdf->Cell(0, 10, utf8_decode("Morador: $morador " . ($morador === 'Sim' ? "($morador_detalhes)" : "")), 0, 1);

    $pdf->Ln(5);

    // Exibir a tabela de notas
    $pdf->TabelaNotas($notasAluno);

    // Exibir faltas e observações
    $pdf->Ln();
    $pdf->Cell(0, 10, utf8_decode('Faltas: ') . utf8_decode($faltas), 0, 1);
    $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes));
}

   


    // Fechar a conexão
    $stmt->close();


    // Gerar o arquivo PDF e forçar o download
    $pdf->Output('D', 'boletins_turma_' . $turma_id . '.pdf');  // 'D' força o download do PDF
    exit();
}


// Alterar a consulta para refletir o nome correto da coluna "numero" na tabela turmas
$query = "SELECT numero FROM turmas";
$stmt = $conn->prepare($query);
$stmt->execute();
$stmt->bind_result($turma_numero);
?>