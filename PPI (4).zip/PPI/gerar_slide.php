

<?php
// Iniciar a sessão
session_start();


// Verificar se o usuário está autenticado e é um administrador
if (!isset($_SESSION['email']) || $_SESSION['user_type'] !== 'administrador') {
    header("Location: f_login.php");
    exit();
}


// Incluir as configurações e a conexão com o banco de dados
include_once 'config.php';


// Obter o nome e a foto do perfil do administrador
$stmt = $conn->prepare("SELECT username, foto_perfil FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $_SESSION['email']);
$stmt->execute();
$stmt->bind_result($nome, $foto_perfil);
$stmt->fetch();
$stmt->close();


// Incluir o FPDF
require_once('fpdf/fpdf.php');


// Definir a classe FPDF para gerar o slide
class PDF extends FPDF {
    // Cabeçalho
    function Header() {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, utf8_decode('Slide de Notas'), 0, 1, 'C');
    }

    // Rodapé
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo(), 0, 0, 'C');
    }

    // Método para exibir a tabela de notas
    function TabelaNotas($notas) {
        $this->SetFont('Arial', 'B', 8); // Fonte menor para ajustar na página
        $this->Cell(50, 10, utf8_decode('Disciplina'), 1, 0, 'C');
        $this->Cell(20, 10, utf8_decode('P1'), 1, 0, 'C');
        $this->Cell(20, 10, utf8_decode('AIS'), 1, 0, 'C');
        $this->Cell(30, 10, utf8_decode('Nota Semestre 1'), 1, 0, 'C');
        $this->Cell(20, 10, utf8_decode('P2'), 1, 0, 'C');
        $this->Cell(30, 10, utf8_decode('Mostra Ciências'), 1, 0, 'C');
        $this->Cell(20, 10, utf8_decode('PPI'), 1, 0, 'C');
        $this->Cell(30, 10, utf8_decode('Nota Semestre 2'), 1, 0, 'C');
        $this->Cell(20, 10, utf8_decode('Nota Final'), 1, 1, 'C');

        $this->SetFont('Arial', '', 8); // Fonte menor para ajustar na página

        foreach ($notas as $nota) {
            $this->Cell(50, 10, utf8_decode($nota['disciplina']), 1, 0, 'C');
            $this->Cell(20, 10, $nota['parcial_1'], 1, 0, 'C');
            $this->Cell(20, 10, $nota['ais'], 1, 0, 'C');
            $this->Cell(30, 10, $nota['nota_semestre_1'], 1, 0, 'C');
            $this->Cell(20, 10, $nota['parcial_2'], 1, 0, 'C');
            $this->Cell(30, 10, $nota['mostra_ciencias'], 1, 0, 'C');
            $this->Cell(20, 10, $nota['ppi'], 1, 0, 'C');
            $this->Cell(30, 10, $nota['nota_semestre_2'], 1, 0, 'C');
            $this->Cell(20, 10, $nota['nota_final'], 1, 1, 'C');
        }
    }

    // Exibir a foto do aluno
    function ExibirFoto($foto) {
        if ($foto) {
            $caminho_foto = 'uploads/' . ltrim($foto, 'uploads/');
            if (file_exists($caminho_foto)) {
                $this->Image($caminho_foto, 10, 30, 30, 30);
            } else {
                $this->SetFont('Arial', 'I', 8);
                $this->Cell(0, 10, utf8_decode('Imagem não disponível'), 0, 1, 'C');
            }
        } else {
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, utf8_decode('Sem foto'), 0, 1, 'C');
        }
    }

    // Exibir as informações do aluno
    function ExibirInformacoesAluno($aluno) {
        $this->SetFont('Arial', 'B', 8); // Fonte menor
        $this->Ln(5);
        $this->Cell(0, 10, utf8_decode("Nome: " . $aluno['nome']), 0, 1);
        $this->SetFont('Arial', '', 8); // Fonte menor
        
        $this->Cell(0, 10, utf8_decode("Telefone: " . $aluno['telefone']), 0, 1);
        $this->Ln(5);

        // Informações adicionais do aluno
        $this->SetFont('Arial', 'B', 8);
        $this->Cell(0, 10, utf8_decode("Informações Adicionais:"), 0, 1);
        $this->SetFont('Arial', '', 8);
        $this->Cell(0, 10, utf8_decode("Reprovações: " . $aluno['reprovacoes']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Acompanhamento: " . $aluno['acompanhamento']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Apoio Psicológico: " . $aluno['apoio_psicologico']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Auxílio Permanência: " . $aluno['auxilio_permanencia']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Cotista: " . $aluno['cotista']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Estágio: " . $aluno['estagio']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Acompanhamento de Saúde: " . $aluno['acompanhamento_saude']), 0, 1);
        $this->Cell(0, 10, utf8_decode("Projetos: Ensino(" . $aluno['projeto_ensino'] . ") | Pesquisa(" . $aluno['projeto_pesquisa'] . ") | Extensão(" . $aluno['projeto_extensao'] . ")"), 0, 1);
        $this->Ln(5);
    }

    // Prevenir quebra de página ao adicionar conteúdo
    function CheckPageBreak($altura) {
        if ($this->GetY() + $altura > 290) { // Evita ultrapassar o limite da página
            $this->AddPage();
        }
    }
}




// Verificar se foi enviado o ID da turma para gerar o boletim
if (isset($_GET['turma_id'])) {
    $turma_id = $_GET['turma_id'];


    // Alterar a consulta para refletir a relação entre discentes, turmas e disciplinas
    $query = "
    SELECT d.numero_matricula, d.nome, d.foto, d.uf, d.telefone, d.reprovacoes, d.acompanhamento, 
    d.apoio_psicologico, d.auxilio_permanencia, d.cotista, d.estagio, d.acompanhamento_saude, 
    d.projeto_pesquisa, d.projeto_extensao, d.projeto_ensino, d.morador, d.morador_detalhes, 
    d.deficiencia, d.deficiencia_detalhes, d.alergia, d.alergia_detalhes, 
    dis.nome AS disciplina_nome, 
    COALESCE(n.parcial_1, 0) AS parcial_1, COALESCE(n.ais, 0) AS ais, COALESCE(n.nota_semestre_1, 0) AS nota_semestre_1, 
    COALESCE(n.parcial_2, 0) AS parcial_2, COALESCE(n.mostra_ciencias, 0) AS mostra_ciencias, COALESCE(n.ppi, 0) AS ppi, 
    COALESCE(n.nota_semestre_2, 0) AS nota_semestre_2, COALESCE(n.faltas, 0) AS faltas, COALESCE(n.observacoes, '') AS observacoes, 
    COALESCE(n.nota_final, 0) AS nota_final
FROM discentes d
LEFT JOIN discentes_turmas dt ON d.numero_matricula = dt.numero_matricula
LEFT JOIN notas n ON d.numero_matricula = n.discente_id AND dt.turma_numero = n.turma_numero
LEFT JOIN disciplinas dis ON n.disciplina_id = dis.id
WHERE dt.turma_numero = ?
ORDER BY d.nome ASC;
";






    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $turma_id); // Bind da variável turma_id
    $stmt->execute();
    $stmt->bind_result(
        $numero_matricula, $nome, $foto, $uf, $telefone, $reprovacoes, 
        $acompanhamento, $apoio_psicologico, $auxilio_permanencia, $cotista, 
        $estagio, $acompanhamento_saude, $projeto_pesquisa, $projeto_extensao, 
        $projeto_ensino, $morador, $morador_detalhes, $deficiencia, $deficiencia_detalhes, 
        $alergia, $alergia_detalhes, $disciplina_nome, 
        $parcial_1, $ais, $nota_semestre_1, $parcial_2, 
        $mostra_ciencias, $ppi, $nota_semestre_2, $faltas, 
        $observacoes, $nota_final
    );
    


    // Criar o PDF em formato paisagem (landscape)
    $pdf = new PDF('L', 'mm', 'A4');  // 'L' define a orientação como paisagem
    $pdf->AddPage();


    // Definir a fonte para o texto em UTF-8
    $pdf->SetFont('Arial', '', 12);  // Fonte Arial já suporta UTF-8


    // Gerar PDF para cada aluno
$notasAluno = [];
$alunoAnterior = null;

while ($stmt->fetch()) {
    if ($alunoAnterior !== $nome) {
        if ($alunoAnterior !== null) {
            $pdf->AddPage();

            // Exibir foto e nome do aluno
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(0, 10, utf8_decode('Aluno: ') . utf8_decode($alunoAnterior), 0, 1, 'C');
            $pdf->Ln();

            // Exibir foto
            $pdf->ExibirFoto($foto);
            $pdf->Ln(40);

            // Exibir dados adicionais do aluno
            $pdf->SetFont('Arial', '', 10);
            $pdf->Cell(0, 10, utf8_decode("Reprovações: $reprovacoes"), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Acompanhamento: $acompanhamento | Apoio Psicológico: $apoio_psicologico"), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Auxílio Permanência: $auxilio_permanencia | Cotista: $cotista | Estágio: $estagio"), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Acompanhamento Saúde: $acompanhamento_saude | Pesquisa: $projeto_pesquisa | Extensão: $projeto_extensao | Ensino: $projeto_ensino"), 0, 1);

            // Informações de moradia, deficiência e alergia
            $pdf->Cell(0, 10, utf8_decode("Morador: $morador " . ($morador === 'Sim' ? "($morador_detalhes)" : "")), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Deficiência: $deficiencia " . ($deficiencia === 'Sim' ? "($deficiencia_detalhes)" : "")), 0, 1);
            $pdf->Cell(0, 10, utf8_decode("Alergia: $alergia " . ($alergia === 'Sim' ? "($alergia_detalhes)" : "")), 0, 1);

            $pdf->Ln(5);

            // Exibir a tabela de notas
            $pdf->TabelaNotas($notasAluno);

            // Exibir faltas e observações
            $pdf->Ln();
            $pdf->Cell(0, 10, utf8_decode('Faltas: ') . utf8_decode($faltas), 0, 1);
            $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes));
        }

        // Resetar as notas para o novo aluno
        $notasAluno = [];
        $alunoAnterior = $nome;
    }

    // Adicionar as notas do aluno
    $notasAluno[] = [
        'disciplina' => $disciplina_nome,
        'parcial_1' => $parcial_1,
        'ais' => $ais,
        'nota_semestre_1' => $nota_semestre_1,
        'parcial_2' => $parcial_2,
        'mostra_ciencias' => $mostra_ciencias,
        'ppi' => $ppi,
        'nota_semestre_2' => $nota_semestre_2,
        'nota_final' => $nota_final
    ];
}

// Gerar a última página para o último aluno
if ($alunoAnterior !== null) {
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, utf8_decode('Aluno: ') . utf8_decode($alunoAnterior), 0, 1, 'C');
    $pdf->Ln();

    // Exibir foto
    $pdf->ExibirFoto($foto);
    $pdf->Ln(40);

    // Exibir dados adicionais do aluno
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 10, utf8_decode("Reprovações: $reprovacoes"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Acompanhamento: $acompanhamento | Apoio Psicológico: $apoio_psicologico"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Auxílio Permanência: $auxilio_permanencia | Cotista: $cotista | Estágio: $estagio"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Acompanhamento Saúde: $acompanhamento_saude | Pesquisa: $projeto_pesquisa | Extensão: $projeto_extensao | Ensino: $projeto_ensino"), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Morador: $morador " . ($morador === 'Sim' ? "($morador_detalhes)" : "")), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Deficiência: $deficiencia " . ($deficiencia === 'Sim' ? "($deficiencia_detalhes)" : "")), 0, 1);
    $pdf->Cell(0, 10, utf8_decode("Alergia: $alergia " . ($alergia === 'Sim' ? "($alergia_detalhes)" : "")), 0, 1);

    $pdf->Ln(5);

    // Exibir a tabela de notas
    $pdf->TabelaNotas($notasAluno);

    // Exibir faltas e observações
    $pdf->Ln();
    $pdf->Cell(0, 10, utf8_decode('Faltas: ') . utf8_decode($faltas), 0, 1);
    $pdf->MultiCell(0, 10, utf8_decode('Observações: ') . utf8_decode($observacoes));
}

   


    // Fechar a conexão
    $stmt->close();


    // Gerar o arquivo PDF e forçar o download
    $pdf->Output('D', 'boletins_turma_' . $turma_id . '.pdf');  // 'D' força o download do PDF
    exit();
}


// Alterar a consulta para refletir o nome correto da coluna "numero" na tabela turmas
$query = "SELECT numero FROM turmas";
$stmt = $conn->prepare($query);
$stmt->execute();
$stmt->bind_result($turma_numero);
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerar Slides</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Forum:wght@700&display=swap" rel="stylesheet">
    <link href="style.css" rel="stylesheet" type="text/css"></head>
    <style>
   
    #discentesTable td {
        background-color: white; /* Sem aspas no valor */
    }
    #discentesNota td {
        background-color: white; /* Sem aspas no valor */
    }
    </style>


<body>
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-3 sidebar">
                <div class="separator mb-3"></div>
                <div class="signe-text">SIGNE</div>
                <div class="separator mt-3 mb-3"></div>
                <button onclick="location.href='f_pagina_adm.php'">
                    <i class="fas fa-home"></i> Início
                </button>
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#expandable-menu" aria-expanded="false" aria-controls="expandable-menu">
                    <i id="toggle-icon" class="fas fa-plus"></i> Cadastrar
                </button>
                <div id="expandable-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='cadastrar_adm.php'">
                            <i class="fas fa-plus"></i> Cadastrar Administrador
                        </button>
                        <button onclick="location.href='cadastrar_curso.php'">
                            <i class="fas fa-plus"></i> Cadastrar Curso
                        </button>
                        <button onclick="location.href='cadastrar_disciplina.php'">
                            <i class="fas fa-plus"></i> Cadastrar Disciplina
                        </button>
                        <button onclick="location.href='cadastrar_docente.php'">
                            <i class="fas fa-plus"></i> Cadastrar Docente
                        </button>
                        <button onclick="location.href='cadastrar_setor.php'">
                            <i class="fas fa-plus"></i> Cadastrar Setor
                        </button>
                        <button onclick="location.href='cadastrar_turma.php'">
                            <i class="fas fa-plus"></i> Cadastrar Turma
                        </button>
                    </div>
                </div>
                <button onclick="location.href='gerar_boletim.php'">
                    <i class="fas fa-file-alt"></i> Gerar Boletim
                </button>
                <button onclick="location.href='gerar_slide.php'">
                    <i class="fas fa-sliders-h"></i> Gerar Slide Pré Conselho
                </button>
               
                <button class="btn btn-light" type="button" data-bs-toggle="collapse" data-bs-target="#list-menu" aria-expanded="false" aria-controls="list-menu">
                    <i id="toggle-icon" class="fas fa-list"></i> Listar
                </button>


                <div id="list-menu" class="collapse expandable-container">
                    <div class="expandable-menu">
                        <button onclick="location.href='listar_administradores.php'">
                            <i class="fas fa-list"></i> Administradores
                        </button>
                        <button onclick="location.href='listar_cursos.php'">
                            <i class="fas fa-list"></i> Cursos
                        </button>
                        <button onclick="location.href='listar_discentes.php'">
                            <i class="fas fa-list"></i> Discentes
                        </button>
                        <button onclick="location.href='listar_disciplinas.php'">
                            <i class="fas fa-list"></i> Disciplinas
                        </button>
                        <button onclick="location.href='listar_docentes.php'">
                            <i class="fas fa-list"></i> Docentes
                        </button>
                        <button onclick="location.href='listar_setores.php'">
                            <i class="fas fa-list"></i> Setores
                        </button>
                        <button onclick="location.href='listar_turmas.php'">
                            <i class="fas fa-list"></i> Turmas
                        </button>
                    </div>
                </div>
                <button onclick="location.href='meu_perfil.php'">
                    <i class="fas fa-user"></i> Meu Perfil
                </button>
                <button class="btn btn-danger" onclick="location.href='sair.php'">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>
            <div class="col-md-9 main-content">
            <div class="container">
                    <div class="header-container">
                        <img src="imgs/iffar.png" alt="Logo do IFFAR" class="logo">
                        <div class="title ms-3">Gerar Slides</div>
                        <div class="ms-auto d-flex align-items-center">
                            <div class="profile-info d-flex align-items-center">
                                <div class="profile-details me-2">
                                    <span><?php echo htmlspecialchars($nome); ?></span>
                                </div>
                                <?php if (!empty($foto_perfil) && file_exists('uploads/' . basename($foto_perfil))): ?>
                                    <img src="uploads/<?php echo htmlspecialchars(basename($foto_perfil)); ?>" alt="Foto do Administrador" width="50">
                                <?php else: ?>
                                    <img src="imgs/admin-photo.png" alt="Foto do Administrador" width="50">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container mt-4">
                <div class="card shadow">
                       
                        <div class="card-body">
   
    <!-- Tabela com as turmas -->
    <table  id="discentesTable" class="table table-bordered table-hover table-sm align-middle">
                <thead class="table-dark">
            <tr>
                <th>Número da Turma</th>
                <th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($stmt->fetch()) { ?>
                <tr>
                    <td><?php echo utf8_decode($turma_numero); ?></td>
                    <td class="text-center">
                        <!-- Botão para gerar o boletim da turma -->
                        <form action="" method="get">
                            <input type="hidden" name="turma_id" value="<?php echo $turma_numero; ?>">
                            <button type="submit" class="btn btn-success btn-sm ">
                                <i class="fas fa-file-alt me-2"></i> Gerar Slide
                            </button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>


<?php
// Fechar a conexão
$stmt->close();
?>
